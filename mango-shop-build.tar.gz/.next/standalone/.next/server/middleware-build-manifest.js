globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/ZCPAtuKYaMgz5ymcKO4ed/_buildManifest.js",
    "static/ZCPAtuKYaMgz5ymcKO4ed/_ssgManifest.js",
    "static/ZCPAtuKYaMgz5ymcKO4ed/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2jjnafy-v_mvn.js",
    "static/chunks/242x7dx0zu3hf.js",
    "static/chunks/0m89jrpzvbcl3.js",
    "static/chunks/10ub08wlsawhl.js",
    "static/chunks/1b-q5yg95-zcx.js",
    "static/chunks/turbopack-2c3mg3r-05n1w.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/2jjnafy-v_mvn.js",
        "static/chunks/242x7dx0zu3hf.js",
        "static/chunks/0m89jrpzvbcl3.js",
        "static/chunks/10ub08wlsawhl.js",
        "static/chunks/1b-q5yg95-zcx.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/2jjnafy-v_mvn.js",
        "static/chunks/242x7dx0zu3hf.js",
        "static/chunks/0m89jrpzvbcl3.js",
        "static/chunks/10ub08wlsawhl.js",
        "static/chunks/1b-q5yg95-zcx.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/(frontend)/[lang]/page": {
      "otherChunks": [
        "static/chunks/2jjnafy-v_mvn.js",
        "static/chunks/242x7dx0zu3hf.js",
        "static/chunks/0m89jrpzvbcl3.js",
        "static/chunks/10ub08wlsawhl.js",
        "static/chunks/1b-q5yg95-zcx.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/(frontend)/[lang]/[...rest]/page": {
      "otherChunks": [
        "static/chunks/2jjnafy-v_mvn.js",
        "static/chunks/242x7dx0zu3hf.js",
        "static/chunks/0m89jrpzvbcl3.js",
        "static/chunks/10ub08wlsawhl.js",
        "static/chunks/1b-q5yg95-zcx.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/(frontend)/[lang]/blog/page": {
      "otherChunks": [
        "static/chunks/2jjnafy-v_mvn.js",
        "static/chunks/242x7dx0zu3hf.js",
        "static/chunks/0m89jrpzvbcl3.js",
        "static/chunks/10ub08wlsawhl.js",
        "static/chunks/1b-q5yg95-zcx.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/(frontend)/[lang]/blog/[slug]/page": {
      "otherChunks": [
        "static/chunks/2jjnafy-v_mvn.js",
        "static/chunks/242x7dx0zu3hf.js",
        "static/chunks/0m89jrpzvbcl3.js",
        "static/chunks/10ub08wlsawhl.js",
        "static/chunks/1b-q5yg95-zcx.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/(frontend)/[lang]/cart/page": {
      "otherChunks": [
        "static/chunks/2jjnafy-v_mvn.js",
        "static/chunks/242x7dx0zu3hf.js",
        "static/chunks/0m89jrpzvbcl3.js",
        "static/chunks/10ub08wlsawhl.js",
        "static/chunks/1b-q5yg95-zcx.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/(frontend)/[lang]/category/[slug]/page": {
      "otherChunks": [
        "static/chunks/2jjnafy-v_mvn.js",
        "static/chunks/242x7dx0zu3hf.js",
        "static/chunks/0m89jrpzvbcl3.js",
        "static/chunks/10ub08wlsawhl.js",
        "static/chunks/1b-q5yg95-zcx.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/(frontend)/[lang]/checkout/page": {
      "otherChunks": [
        "static/chunks/2jjnafy-v_mvn.js",
        "static/chunks/242x7dx0zu3hf.js",
        "static/chunks/0m89jrpzvbcl3.js",
        "static/chunks/10ub08wlsawhl.js",
        "static/chunks/1b-q5yg95-zcx.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/(frontend)/[lang]/order/[number]/page": {
      "otherChunks": [
        "static/chunks/2jjnafy-v_mvn.js",
        "static/chunks/242x7dx0zu3hf.js",
        "static/chunks/0m89jrpzvbcl3.js",
        "static/chunks/10ub08wlsawhl.js",
        "static/chunks/1b-q5yg95-zcx.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/(frontend)/[lang]/pages/[slug]/page": {
      "otherChunks": [
        "static/chunks/2jjnafy-v_mvn.js",
        "static/chunks/242x7dx0zu3hf.js",
        "static/chunks/0m89jrpzvbcl3.js",
        "static/chunks/10ub08wlsawhl.js",
        "static/chunks/1b-q5yg95-zcx.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/(frontend)/[lang]/product/[slug]/page": {
      "otherChunks": [
        "static/chunks/2jjnafy-v_mvn.js",
        "static/chunks/242x7dx0zu3hf.js",
        "static/chunks/0m89jrpzvbcl3.js",
        "static/chunks/10ub08wlsawhl.js",
        "static/chunks/1b-q5yg95-zcx.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/(frontend)/[lang]/shop/page": {
      "otherChunks": [
        "static/chunks/2jjnafy-v_mvn.js",
        "static/chunks/242x7dx0zu3hf.js",
        "static/chunks/0m89jrpzvbcl3.js",
        "static/chunks/10ub08wlsawhl.js",
        "static/chunks/1b-q5yg95-zcx.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/(frontend)/[lang]/track-order/page": {
      "otherChunks": [
        "static/chunks/2jjnafy-v_mvn.js",
        "static/chunks/242x7dx0zu3hf.js",
        "static/chunks/0m89jrpzvbcl3.js",
        "static/chunks/10ub08wlsawhl.js",
        "static/chunks/1b-q5yg95-zcx.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/(frontend)/[lang]/videos/page": {
      "otherChunks": [
        "static/chunks/2jjnafy-v_mvn.js",
        "static/chunks/242x7dx0zu3hf.js",
        "static/chunks/0m89jrpzvbcl3.js",
        "static/chunks/10ub08wlsawhl.js",
        "static/chunks/1b-q5yg95-zcx.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/(payload)/admin/[[...segments]]/page": {
      "otherChunks": [
        "static/chunks/2jjnafy-v_mvn.js",
        "static/chunks/242x7dx0zu3hf.js",
        "static/chunks/0m89jrpzvbcl3.js",
        "static/chunks/10ub08wlsawhl.js",
        "static/chunks/1b-q5yg95-zcx.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
