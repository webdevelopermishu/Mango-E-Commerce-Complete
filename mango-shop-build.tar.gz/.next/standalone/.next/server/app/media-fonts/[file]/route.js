var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/media-fonts/[file]/route.js")
R.c("server/chunks/[externals]__0g_1lid9gtoc0._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_0o4x-g2qorwry._.js")
R.c("server/chunks/_next-internal_server_app_media-fonts_[file]_route_actions_0uqyef1lga9xh.js")
R.m(2807)
module.exports=R.m(2807).exports
