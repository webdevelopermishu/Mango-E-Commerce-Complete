var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__0pleu0xjoqttt._.js")
R.c("server/chunks/[root-of-the-server]__1s0cs27mc1ki9._.js")
R.m(489997)
module.exports=R.m(489997).exports
