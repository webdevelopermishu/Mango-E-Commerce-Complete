module.exports=[270406,(a,b,c)=>{b.exports=a.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},575465,(a,b,c)=>{"use strict";b.exports=a.r(924951).vendored["react-rsc"].ReactDOM},758098,function(a){a.n(a.i(866366))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__09955hsjqfptf._.js.map